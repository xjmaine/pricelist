var jprice = [
    {
        "Package": "Bronze",
        "Price": "$150",
    },
    {
        "Package": "Silver",
        "Price": "$150",
    },
    {
        "Package": "Gold",
        "Price": "$350",
    }
]

var output = document.getElementById('output');
output.innerHTML = jprice.Price;